package com.function.interfaces;

import java.util.function.Consumer;

class Taste implements Consumer<String>{

	@Override
	public void accept(String input) {
		
		System.out.println(input);
	}
	
}

public class ConsumerDemo {

	public static void main(String[] args) {
		
		Consumer<String> taste=new Taste();
		taste.accept("apple taste is sweet");

	}

}
