package com.function.interfaces;

import java.util.function.Consumer;

public class ConsumerDemo2 {

	public static void main(String[] args) {
		
		Consumer<String> taste= input -> System.out.println(input);
		taste.accept("apple taste is sweet");
		
	}

}
/*
Consumer interface takes an input and does not return anything.  

*/