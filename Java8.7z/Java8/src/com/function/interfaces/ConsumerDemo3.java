package com.function.interfaces;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerDemo3 {

	public static void main(String[] args) {
		
		Consumer<String> consumer= t -> System.out.println(t);
		consumer.accept("hello vivek");
		
		// example -2 method of consumer
		
		Consumer<String> consumer2= input -> System.out.println(input+" world !");
		Consumer<String> consumer3= input -> System.out.println(input+" java");
		
		consumer2.andThen(consumer3).accept("hello");
		
		System.out.println("............................");
		// implementation of forEach
		
		List<Integer> arr=Arrays.asList(1,2,3,4,5,6,7,8);
		Consumer<Integer> consumer4= input -> System.out.println(input);
		arr.forEach(consumer4);
		
	}

}
