package com.function.interfaces;

import java.util.function.Function;

class Lengths implements Function<String, Integer>{

	@Override
	public Integer apply(String s) {
		
		Integer i= s.length();;
		return i;
	}
	
	
}
public class FunctionDemo {

	public static void main(String[] args) {
		
         // traditional way
		Lengths l=new Lengths();
	    Integer len=l.apply("vivek kumar sagar comes from noida ");
		System.out.println(len);
	}

}
