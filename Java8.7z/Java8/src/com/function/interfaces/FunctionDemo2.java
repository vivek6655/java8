package com.function.interfaces;

import java.util.function.Function;

public class FunctionDemo2 {

	public static void main(String[] args) {
		
		Function<String, Integer> f= s -> s.length();
		System.out.println(f.apply("vivek kumar sagar"));
	}

}
/*
whenever you have requirement
 to take input and return output then we
  should go for Function interface 

*/