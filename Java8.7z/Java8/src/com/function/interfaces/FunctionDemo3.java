package com.function.interfaces;

import java.util.Scanner;
import java.util.function.Function;

public class FunctionDemo3 {

	public static void main(String[] args) {
	
		// example-1
		
		Function<Integer, String> function=(number)->{
			
			if(number % 2==0) {
				
				return "number "+number+" is even";
			}else {
				
				return "number "+number+" is odd";
			}	
		};
		
//		Scanner sc=new Scanner(System.in);
//		System.out.println("enter a number");
//		int number=sc.nextInt();
       System.out.println(function.apply(13));		
       
       System.out.println("......................");
       
       // example -2
       
       Function<String,Integer> function2=(t)->t.length();
       Function<Integer,Integer> function3=(numbers)->numbers * 2;
       
       Integer lenOfString=  function2.andThen(function3).apply("vivek");
       System.out.println("length of name : "+lenOfString);

	}

}
