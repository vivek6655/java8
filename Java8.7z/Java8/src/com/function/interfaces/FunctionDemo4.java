package com.function.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FunctionDemo4 {


	public static void main(String[] args) {
		
		List<User> listOfUsers =new ArrayList<>();
		listOfUsers.add(new User(100,"vivek","123456","vivek@"));
		listOfUsers.add(new User(101,"kumar","12345634","kumar@"));
		listOfUsers.add(new User(102,"sagar","12345621","sagar@"));
		listOfUsers.add(new User(103,"ravi","1234562345","ravi@"));
		listOfUsers.add(new User(104,"prasad","123456987","prasad@"));
	
		System.out.println("traditional way...........................");
		
		List<UserDTO> userDTO=new ArrayList<>();
		for(User user:listOfUsers) {
			
			userDTO.add(new UserDTO(user.getId(),user.getName(),user.getEmail()));
		}
	
       for(UserDTO list:userDTO) {
			
			System.out.println(list);
		}
	
		System.out.println("by using strean api .............................................");
		
       List<UserDTO> userDTOs=listOfUsers.stream()
      .map((User user)->new UserDTO(user.getId(),user.getName(),user.getEmail()))
       .collect(Collectors.toList());
       
       userDTOs.forEach(System.out::println);
		
	}

}

class UserDTO{
	
	private int id;
	private String name;
	private String email;
	
	public UserDTO(int id, String name, String email) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", name=" + name + ", email=" + email + "]";
	}
	
	
}
class User{
	
	private int id;
	private String name;
	private String password;
	private String email;
	
	public User(int id, String name, String password, String email) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", password=" + password + ", email=" + email + "]";
	}
	
	
	
}