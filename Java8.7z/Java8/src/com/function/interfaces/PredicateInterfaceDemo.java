package com.function.interfaces;

import java.util.Scanner;
import java.util.function.Predicate;

class EvenOdd implements Predicate<Integer>{

	@Override
	public boolean test(Integer i) {
		
		if(i%2==0) {
			return true;
		}else {
			
			return	false;
		}
		
	}
	
}
public class PredicateInterfaceDemo {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		int evenOddNumber=sc.nextInt();
		
		Predicate<Integer> pp=new EvenOdd();
		System.out.println(pp.test(evenOddNumber));

	}

}
