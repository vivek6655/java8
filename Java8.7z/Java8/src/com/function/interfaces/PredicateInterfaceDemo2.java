package com.function.interfaces;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PredicateInterfaceDemo2 {

	public static void main(String[] args) {
		
		
		
		Predicate<Integer> evenOddNumber=i->{
			
			if(i%2==0) {
				
				return true;
			}else
			{
				return false;
			}
			
		};
	
		System.out.println(evenOddNumber.test(10));
		
		// example -2 sort the array list  
		
		System.out.println("................example -2..............................");
		List<Integer> list=Arrays.asList(1,2,3,4,5,6,7,8,9);
		
		Predicate<Integer> predicate2=(x)-> x > 5 ;
		Predicate<Integer> predicate3=(x)-> x < 8 ;
		list.stream().filter(predicate2.and(predicate3)).forEach(System.out::println);
		
		
		System.out.println("................example -3..............................");
		
		Predicate<String> predicate4 = x -> x.length()==3;
		Predicate<String> startWithA = x-> x.startsWith("A");
		
		List<String> lists = Arrays.asList("A","AA","AAA","B","BB","BBB");
		
		List<String> collect=lists.stream().filter(predicate4.or(startWithA)).collect(Collectors.toList());
		collect.forEach(System.out::println);
		
		
		
	}

}
