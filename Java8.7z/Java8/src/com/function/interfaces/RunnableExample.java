package com.function.interfaces;

class MyThread implements Runnable{

	@Override
	public void run() {
		System.out.println("my run method is called");
		
	}
	
}
public class RunnableExample {

	public static void main(String[] args) {
		
		MyThread t=new MyThread();
		Thread thread=new Thread(t);
		thread.start();
		
	}

}
