package com.function.interfaces;

public class RunnableExample2 {

	public static void main(String[] args) {
		
		Runnable r=()->System.out.println("please call run method to print this");
		Thread thread=new Thread(r);
		thread.start();

	}

}
/*
 Runnable interface is exactly same as supplier interface example

*/