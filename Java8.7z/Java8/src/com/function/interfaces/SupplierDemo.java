package com.function.interfaces;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.function.Supplier;

class SupplierImp implements Supplier<String>{

	@Override
	public String get() {
		
		LocalDateTime now= LocalDateTime.now();
		//return now; 
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");  
        String formatDateTime = now.format(format);
		return formatDateTime;
		
	}
	
}

public class SupplierDemo {

	public static void main(String[] args) {
		
		Supplier<String> dateTime=new SupplierImp();
		System.out.println(dateTime.get());
		
	}

}
