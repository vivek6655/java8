package com.function.interfaces;

import java.time.LocalDateTime;
import java.util.function.Supplier;

public class SupplierDemo2 {

	public static void main(String[] args) {
	
		Supplier<LocalDateTime> dateTime =()-> LocalDateTime.now();
		System.out.println(dateTime.get());
			

	}

}
/*
if you want to return something but don't want to give input 
then we should go for supplier interface

*/