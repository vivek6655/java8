package com.function.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class SupplierDemo3 {

	public static Supplier<List<Product>> getProductList() {
		
        Supplier<List<Product>> productSupplier=()->{
			
			List<Product> productList=new ArrayList<>();
			
			productList.add(new Product(100,"HP",25000f));
			productList.add(new Product(101,"DELL",30000f));
			productList.add(new Product(103,"APPLE",250000f));
			productList.add(new Product(104,"ASUS",70000f));
			productList.add(new Product(105,"LENOVO",20000f));
			return productList;
				
		};
       return productSupplier;
		
	}
	
	public static void main(String[] args) {
		
		System.out.println(getProductList().get());
		
	}

}

class Product{
	
	private int id;
	private String name;
	private float price;
	
	public Product() {
		super();
	}

	public Product(int id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
	
}