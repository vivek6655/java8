package com.function.interfaces;

@FunctionalInterface
interface Shapes{
	
	void draw();
	
}
public class Test1 {

	public static void main(String[] args) {
	
		// lambda expresion
		Shapes s=()->System.out.println("draw a retangel");
		s.draw();
		

	}

}
